let currentLang = 'vi';

document.addEventListener('DOMContentLoaded', () => {
  const savedLang = localStorage.getItem('champasenLang') || 'vi';
  setLanguage(savedLang);

  const btnVi = document.getElementById('lang-vi');
  const btnEn = document.getElementById('lang-en');
  const mobileToggle = document.querySelector('.mobile-toggle');
  const mainNav = document.getElementById('mainNav');

  if (btnVi) btnVi.addEventListener('click', () => setLanguage('vi'));
  if (btnEn) btnEn.addEventListener('click', () => setLanguage('en'));

  if (mobileToggle && mainNav) {
    mobileToggle.addEventListener('click', () => {
      const open = mainNav.classList.toggle('is-open');
      mobileToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  document.querySelectorAll('.nav-link, .cta-btn, .btn, .learn-more-btn, .scroll-top').forEach((link) => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (!href || !href.startsWith('#')) return;
      e.preventDefault();
      const target = document.querySelector(href);
      if (target) {
        const offset = 96;
        const top = target.getBoundingClientRect().top + window.pageYOffset - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
      if (mainNav) mainNav.classList.remove('is-open');
      if (mobileToggle) mobileToggle.setAttribute('aria-expanded', 'false');
    });
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 980 && mainNav) {
      mainNav.classList.remove('is-open');
      if (mobileToggle) mobileToggle.setAttribute('aria-expanded', 'false');
    }
  });
});

function setLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('champasenLang', lang);

  const btnVi = document.getElementById('lang-vi');
  const btnEn = document.getElementById('lang-en');

  if (btnVi && btnEn) {
    btnVi.classList.toggle('active', lang === 'vi');
    btnEn.classList.toggle('active', lang === 'en');
  }

  document.documentElement.lang = lang;
  document.title = lang === 'vi'
    ? 'ChampaSen - Thức Ăn Chăn Nuôi & Hậu Cần'
    : 'ChampaSen - Animal Feed & Logistics';

  document.querySelectorAll('[data-en][data-vi]').forEach((el) => {
    const text = el.getAttribute(`data-${lang}`);
    if (text !== null) el.textContent = text;
  });
}

document.addEventListener('keydown', (e) => {
  if (e.altKey && e.key.toLowerCase() === 'l') {
    setLanguage(currentLang === 'vi' ? 'en' : 'vi');
  }
});